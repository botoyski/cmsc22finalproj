public class MainApp {
    public static void main(String[] args) {
        // Call the method to create and display the MainMenu
       MainMenu.createMainMenuFrame();
    }
}